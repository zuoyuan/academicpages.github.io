import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Map;

public class InferenceTopicsForOrgDocs {

	private Map<String, double[]> word2theta = new HashMap<String, double[]>();
	
	private int loadWordsAndTheta(String wordsFile, String thetaFile) {
		BufferedReader wordsReader = this.getReader(wordsFile, "utf-8");
		BufferedReader thetaReader = this.getReader(thetaFile, "utf-8");
		
		int numberOfTopics = -1;
		
		try {
			String wordsLine = wordsReader.readLine(),  thetaLine = thetaReader.readLine();
			numberOfTopics = thetaLine.trim().split("\\s+").length;
			while (wordsLine != null) {
				if (thetaLine == null) {
					System.err.println("# of lines in .words file dose not match the # in .theta file!");
					System.exit(0);
				}
				
				if (word2theta.containsKey(wordsLine.trim())) {
					System.err.println("Duplicate word exist in .words file!");
					System.exit(0);
				}
				
				
				String[] thetaValsInStr = thetaLine.trim().split("\\s+");
				if (thetaValsInStr.length != numberOfTopics) {
					System.err.println("Wrong number of topics in .theta file!");
					System.exit(0);
				}
				
				double[] theta = new double[numberOfTopics];
				for (int i = 0; i != numberOfTopics; i++) {
					theta[i] = Double.valueOf(thetaValsInStr[i]);
				}
				
				word2theta.put(wordsLine.trim(), theta);
				
				wordsLine = wordsReader.readLine();
				thetaLine = thetaReader.readLine();
			}
			wordsReader.close();
			thetaReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return numberOfTopics;
	}
	
	public void InferenceTopics(String wordsFile, String wordsThetaFile, String orgDocsFile, String docsThetaFile) {
		int numberOfTopics = this.loadWordsAndTheta(wordsFile, wordsThetaFile);
		
		BufferedReader orgDocsReader = this.getReader(orgDocsFile, "utf-8");
		BufferedWriter docsThetaWriter = this.getWriter(docsThetaFile, "utf-8");
		
		try {
			String orgDoc = orgDocsReader.readLine();
			while (orgDoc != null) {
				double[] orgTheta = new double[numberOfTopics];
				String[] tokens = orgDoc.trim().split("\\s+");
				int length = 0;
				for (String token : tokens) {
					double[] wordTheta = word2theta.get(token);
					if (wordTheta != null) { // some times word occurs in the original text dose not occur in word network.
						for (int i = 0; i != numberOfTopics; i++) 
							orgTheta[i] += wordTheta[i];
						length++;
					}
				}
				StringBuilder sb = new StringBuilder("");
				for (int i = 0; i != numberOfTopics; i++) {
					orgTheta[i] /= length;
					sb.append(orgTheta[i] + " ");
				}
				docsThetaWriter.append(sb.toString().trim());
				docsThetaWriter.newLine();
				orgDoc = orgDocsReader.readLine();
			}
			
			orgDocsReader.close();
			docsThetaWriter.flush();
			docsThetaWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private BufferedReader getReader(String path, String charset) {
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(
					new FileInputStream(path), charset));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return reader;
	}

	private BufferedWriter getWriter(String path, String charset) {
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new OutputStreamWriter(
					new FileOutputStream(path), charset));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return writer;
	}
	
	public static void main(String args[]) {
		InferenceTopicsForOrgDocs inference = new InferenceTopicsForOrgDocs();
		if (args.length < 4) {
			System.err.println("Lack of parameters!");
			System.exit(0);
		}
		// .words file; word theta file; original text file; original document theta file
		inference.InferenceTopics(args[0], args[1], args[2], args[3]);
	}
}
